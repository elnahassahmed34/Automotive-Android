package com.example.weatherapp.model.forecast

data class Minutely(
    val dt: Double,
    val precipitation: Double
)