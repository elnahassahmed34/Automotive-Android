package com.example.weatherapp.features.map.viewmodel

import androidx.lifecycle.ViewModel
import com.example.weatherapp.model.repo.RepoInterface

class MapVM(private val repo: RepoInterface) : ViewModel() {
}