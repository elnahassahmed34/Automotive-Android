package com.example.weatherapp.model.forecast

data class Snow(
    val `1h`: Double
)