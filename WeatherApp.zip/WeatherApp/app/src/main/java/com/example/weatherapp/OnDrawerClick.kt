package com.example.weatherapp

interface OnDrawerClick {
    fun onClick()
}