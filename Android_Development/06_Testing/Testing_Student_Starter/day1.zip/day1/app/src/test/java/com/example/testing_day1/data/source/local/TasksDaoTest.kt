package com.example.testing_day1.data.source.local

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.testing_day1.data.Task
import com.example.testing_day1.data.source.local.ToDoDatabase
import com.example.testing_day1.data.source.local.TasksDao
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.CoreMatchers.notNullValue
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
@ExperimentalCoroutinesApi
class TasksDaoTest {

    // Rule to allow LiveData testing in instant execution mode
    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var database: ToDoDatabase
    private lateinit var taskDao: TasksDao

    @Before
    fun setup() {
        // Initialize in-memory database
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            ToDoDatabase::class.java
        ).allowMainThreadQueries()
            .build()

        // Get a reference to the DAO
        taskDao = database.taskDao()
    }

    @After
    fun tearDown() {
        // Close the database after the test completes
        database.close()
    }

    @Test
    fun getTaskByID_task1_returnsSameTask() = runTest {
        // Create a sample task
        val task = Task(id = "1", title = "Test Task")

        // Insert the task into the database
        taskDao.insertTask(task)

        // Retrieve the task from the database by ID
        val result = taskDao.getTaskById(task.id)

        // Ensure that the result is not null
        assertThat(result, notNullValue())

        // Optionally compare the actual task with the expected task
        assertThat(result?.title, `is`(task.title))
    }

    @Test
    fun updateTask_AndGetById() = runTest {
        // Step 1: Insert an initial task
        val initialTask = Task(id = "1", title = "Initial Task", description = "Initial Description")
        taskDao.insertTask(initialTask)

        // Step 2: Modify the task details
        val updatedTask = Task(id = initialTask.id, title = "Updated Task", description = "Updated Description")

        // Step 3: Update the task in the database
        val rowsUpdated = taskDao.updateTask(updatedTask)
        assertThat(rowsUpdated, `is`(1)) // Ensure that one row was updated

        // Step 4: Retrieve the task by its ID
        val result = taskDao.getTaskById(initialTask.id)

        // Step 5: Assert that the task has been updated
        assertThat(result, notNullValue())
        assertThat(result?.title, `is`("Updated Task"))
        assertThat(result?.description, `is`("Updated Description"))
    }

}
