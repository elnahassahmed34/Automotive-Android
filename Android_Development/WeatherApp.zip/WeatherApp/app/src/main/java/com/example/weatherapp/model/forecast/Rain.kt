package com.example.weatherapp.model.forecast

data class Rain(
    val `1h`: Double
)